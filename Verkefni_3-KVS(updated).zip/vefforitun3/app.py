from flask import Flask, Request, render_template, request, url_for, json
import urllib.request
from datetime import date
app = Flask(__name__)

@app.route("/")
def index():
    with urllib.request.urlopen("https://api.themoviedb.org/3/discover/movie?api_key=37ddd3333eee1b5117fc2133b993e332&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_watch_monetization_types=flatrate={}") as url:
        gogn = json.loads(url.read().decode())

        
    return render_template("index.html", gogn = gogn)

@app.route("/islenska")
def islenska():
    with urllib.request.urlopen("https://api.themoviedb.org/3/discover/movie?api_key=37ddd3333eee1b5117fc2133b993e332&language=is-IS&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_watch_monetization_types=flatrate={}") as url:
        gogn = json.loads(url.read().decode())

    return render_template("islenska.html", gogn = gogn)

@app.route("/movie/<id>")
def identity(id):  


    with urllib.request.urlopen("https://api.themoviedb.org/3/movie/{}?api_key=37ddd3333eee1b5117fc2133b993e332&language=en-US".format(id)) as url:
        gogn = json.loads(url.read().decode())

    with urllib.request.urlopen("https://api.themoviedb.org/3/movie/{}/credits?api_key=37ddd3333eee1b5117fc2133b993e332&language=en-US".format(id)) as url:
        creds = json.loads(url.read().decode())

    directors = [person for person in creds['crew'] if person['job'] == "Director"]

    d = gogn['release_date']
    d = date.fromisoformat(d)
    d = (d.strftime("%#d-%#m-%Y"))



    return render_template("id.html", gogn = gogn, id = id, d = d, creds = creds, directors = directors)
@app.route("/myndir/<id>")
def islensk(id):  


    with urllib.request.urlopen("https://api.themoviedb.org/3/movie/{}?api_key=37ddd3333eee1b5117fc2133b993e332&language=is-IS".format(id)) as url:
        gogn = json.loads(url.read().decode())

    with urllib.request.urlopen("https://api.themoviedb.org/3/movie/{}/credits?api_key=37ddd3333eee1b5117fc2133b993e332&language=is-IS".format(id)) as url:
        creds = json.loads(url.read().decode())

    directors = [person for person in creds['crew'] if person['job'] == "Director"]

    d = gogn['release_date']
    d = date.fromisoformat(d)
    d = (d.strftime("%#d-%#m-%Y"))



    return render_template("is.html", gogn = gogn, id = id, d = d, creds = creds, directors = directors)

@app.route("/genres/<id>")
def genres(id):
    with urllib.request.urlopen("https://api.themoviedb.org/3/genre/movie/list?api_key=37ddd3333eee1b5117fc2133b993e332&language=en-US".format(id)) as url:
        gogn = json.loads(url.read().decode())

    with urllib.request.urlopen("https://api.themoviedb.org/3/discover/movie?api_key=37ddd3333eee1b5117fc2133b993e332&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_genres={}".format(id)) as url:
        movies = json.loads(url.read().decode())

    genre_name = ""
    for genre in gogn['genres']:
        if genre['id'] == int(id):
            genre_name = genre['name']
            break

    genres = {'genres': [{'id': 28, 'name': 'Action'}, {'id': 12, 'name': 'Adventure'}, {'id': 16, 'name': 'Animation'}, {'id': 35, 'name': 'Comedy'}, {'id': 80, 'name': 'Crime'}, {'id': 99, 'name': 'Documentary'}, {'id': 18, 'name': 'Drama'}, {'id': 10751, 'name': 'Family'}, {'id': 14, 'name': 'Fantasy'}, {'id': 36, 'name': 'History'}, {'id': 27, 'name': 'Horror'}, {'id': 10402, 'name': 'Music'}, {'id': 9648, 'name': 'Mystery'}, {'id': 10749, 'name': 'Romance'}, {'id': 878, 'name': 'Science Fiction'}, {'id': 10770, 'name': 'TV Movie'}, {'id': 53, 'name': 'Thriller'}, {'id': 10752, 'name': 'War'}, {'id': 37, 'name': 'Western'}]}


    return render_template("genre.html", genre_name = genre_name, gogn = gogn, genres = genres, movies = movies)
@app.route("/genresis/<id>")
def genresis(id):
    with urllib.request.urlopen("https://api.themoviedb.org/3/genre/movie/list?api_key=37ddd3333eee1b5117fc2133b993e332&language=is-IS".format(id)) as url:
        gogn = json.loads(url.read().decode())

    with urllib.request.urlopen("https://api.themoviedb.org/3/discover/movie?api_key=37ddd3333eee1b5117fc2133b993e332&language=is-IS&sort_by=popularity.desc&include_adult=false&include_video=false&page=1&with_genres={}".format(id)) as url:
        movies = json.loads(url.read().decode())

    genre_name = ""
    for genre in gogn['genres']:
        if genre['id'] == int(id):
            genre_name = genre['name']
            break

    genres = {'genres': [{'id': 28, 'name': 'Action'}, {'id': 12, 'name': 'Adventure'}, {'id': 16, 'name': 'Animation'}, {'id': 35, 'name': 'Comedy'}, {'id': 80, 'name': 'Crime'}, {'id': 99, 'name': 'Documentary'}, {'id': 18, 'name': 'Drama'}, {'id': 10751, 'name': 'Family'}, {'id': 14, 'name': 'Fantasy'}, {'id': 36, 'name': 'History'}, {'id': 27, 'name': 'Horror'}, {'id': 10402, 'name': 'Music'}, {'id': 9648, 'name': 'Mystery'}, {'id': 10749, 'name': 'Romance'}, {'id': 878, 'name': 'Science Fiction'}, {'id': 10770, 'name': 'TV Movie'}, {'id': 53, 'name': 'Thriller'}, {'id': 10752, 'name': 'War'}, {'id': 37, 'name': 'Western'}]}


    return render_template("genreis.html", genre_name = genre_name, gogn = gogn, genres = genres, movies = movies)

@app.errorhandler(404)
def error(error):
    return render_template("error.html")

app.run(debug=True)